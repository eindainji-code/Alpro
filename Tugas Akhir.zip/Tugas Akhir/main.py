import json
import mechanics as m

with open("data/enemies.json", "r") as f:
    enemies = json.load(f) # mengambil data dalam enemies.json

m.intro()
    
player = m.Choosing() # test untuk membuat karakter
enemy = {
    enemies
}
m.battle(player,enemy)
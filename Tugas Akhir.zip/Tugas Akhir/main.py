import json
import mechanics as m

with open("data/enemies.json", "r") as f:
    enemies = json.load(f)

player = m.Character_Creator() # test untuk membuat karakter

m.loot_drops()
m.inventory()

m.enemy_action("Zombie")